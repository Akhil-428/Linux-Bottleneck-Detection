# Performance report (2026-11-16 20:36)

Samples: 6  |  Period: 2026-11-16 20:30:57 to 2026-11-16 20:31:02

Blank/`n/a` means the metric was unavailable on this system (never a silent zero).

| Metric | Mean | Max |
|---|---|---|
| cpu_percent | 4.74 | 10.56 |
| iowait_percent | 0.01 | 0.05 |
| load1 | 2.12 | 2.15 |
| mem_percent | 6.61 | 6.63 |
| swap_percent | 0.0 | 0.0 |
| disk_read_mbs | 0.0 | 0.0 |
| disk_write_mbs | 0.02 | 0.11 |
| disk_util | 0.6 | 0.96 |
| disk_await_ms | 5.28 | 7.0 |
| psi_cpu_some_pct | 0.17 | 0.24 |
| psi_mem_some_pct | 0.0 | 0.0 |
| psi_io_some_pct | 0.02 | 0.1 |
| runq_wait_per_core | 0.0 | 0.0 |

State time share, CPU: NORMAL 100%

State time share, Memory: NORMAL 100%

State time share, Disk I/O: NORMAL 100%

## Diagnoses

Only POTENTIAL/CONFIRMED rows are contention findings. ELEVATED means 'busy, nothing waiting'.

Counts by resource / state / severity:
- 1 x Process / ELEVATED / INFO

| Time | Resource | State | Severity | Confidence | Method | Diagnosis | Responsible |
|---|---|---|---|---|---|---|---|
| 2026-11-16 20:30:59 | Process | ELEVATED | INFO | LOW | static | CPU-intensive process: 'gnome-shell' (PID 2848) at 171% of a core in 3/3 samples |  |

No contention (POTENTIAL/CONFIRMED) was diagnosed in this period.

## Controlled experiments

| Run | Kind | Verdict |
|---|---|---|
| 20261114-161914-cpu | cpu | PASS |
| 20261114-162011-cpu-benign | cpu-benign | PASS |
| 20261114-162109-disk | disk | PASS |
| 20261114-162209-control | control | PASS |
| 20261114-162307-memory | memory | PASS |

Aggregate validation: `/home/cse-sdpl/OS_Project/Linux-Bottleneck-Detection/data/experiments/suite.md`
