# Linux Bottleneck Detective V2: Presentation Slide Deck (10 Slides)

**Course:** Operating Systems Laboratory / Final Project Presentation  
**Target Duration:** 10–12 Minutes (+ 3-Minute Live Demonstration)  
**Deliverable File:** `reports/PRESENTATION_SLIDES.md`

---

## Slide 1: Title & Overview

### Visual Layout
- **Title:** Linux Bottleneck Detective V2
- **Subtitle:** Autonomous Linux Performance Bottleneck Detection & Explainable Diagnosis
- **Key Concepts:** USE Method • Pressure Stall Information (PSI) • Multi-Metric Persistence • Identity-Aware Attribution
- **Presenter Information:** Operating Systems Lab Project, November 2026

### Slide Content
- **The Core Premise:** Moving beyond raw resource counters (`top`, `vmstat`, `iostat`) to determine whether an operating system resource is **genuinely contended**, explain **why**, and identify the **responsible processes**.
- **Novelty:** Evidence-based state classification (`NORMAL`, `ELEVATED`, `POTENTIAL`, `CONFIRMED`, `RECOVERED`), decoupled severity vs. confidence, and dynamic MAD statistical baselines.

### Speaker Notes (1 Minute)
> "Good morning, professors and evaluators. Today, I am presenting Bottleneck Detective V2. Traditional tools like `top` or `vmstat` give us numbers, but they leave the burden of interpretation to humans. A system with 95% CPU utilization might be doing optimal work or starving tasks in run queues. Bottleneck Detective V2 is designed to understand the difference between high utilization and genuine contention, explain its reasoning transparently, and validate itself with controlled experiments."

---

## Slide 2: The Problem: The Diagnostic Gap

### Visual Layout
- **Two Contrasting Scenarios:**
  - *Scenario A:* 36 cores running 36 computational threads at 100% CPU. Run queue wait = 0 ms, PSI = 0%. **Verdict:** Highly productive batch system.
  - *Scenario B:* 36 cores with 150 threads contending for execution. Run queue wait > 25 ms, PSI = 45%. **Verdict:** Saturated, starving system.
- **The Core Diagnostic Failure of V1 / Traditional Alarms:**
  - Static thresholds flag *both* scenarios as critical alarms.
  - Naive memory alerts treat the page cache as "leaked memory."
  - Single-sample process sorting blames whichever process happened to execute at that exact instant.

### Speaker Notes (1 Minute)
> "Why do traditional tools fail? Consider these two systems. Both report 100% CPU utilization. But in Scenario A, every core is executing productive work without any queuing. In Scenario B, dozens of tasks are waiting for execution time. Traditional threshold alarms cannot tell them apart. Similarly, virtual memory managers naturally use spare RAM for caching, so memory always looks 'full'. Our goal in V2 is to treat waiting—queues and stalls—as the proof of a bottleneck, and utilization merely as context."

---

## Slide 3: Project Objectives

### Visual Layout
- **7 Core Objectives:**
  1. **Sustained Contention Detection:** Filter transient spikes with multi-sample persistence rules ($k \ge 3$ of $W = 5$ samples).
  2. **Multi-State Evidence Modeling:** Separate `ELEVATED` (busy) from `POTENTIAL` (partial) and `CONFIRMED` (verified degradation).
  3. **Decoupled Dimensions:** Separate Severity (overload magnitude) from Confidence (sensor consensus).
  4. **Kernel PSI Integration:** Leverage Linux Pressure Stall Information directly from cumulative microsecond counters.
  5. **Dynamic Rolling Baseline:** Median + MAD deviation detection with absolute safety floors.
  6. **Identity-Aware Attribution:** Track `(PID, start_time)` to eliminate PID-recycling attribution errors.
  7. **Self-Validating Harness:** Built-in controlled workloads to experimentally evaluate detection accuracy.

### Speaker Notes (1 Minute)
> "To solve these issues, we set seven clear objectives. Notice particularly items 2, 3, and 6. We do not just trigger an alarm; we classify the state into ELEVATED, POTENTIAL, or CONFIRMED. We separate how severe an overload is from how confident the evidence is. And we never attribute load using PID alone, because PIDs are recycled by the Linux kernel."

---

## Slide 4: System Architecture

### Visual Layout
```
[ Linux Kernel Interfaces ]
 /proc/stat  |  /proc/schedstat  |  /proc/meminfo  |  /proc/diskstats  |  /proc/pressure/*
       │               │                 │                 │                    │
       ▼               ▼                 ▼                 ▼                    ▼
[ collectors/ Layer (cpu_monitor, memory_monitor, disk_monitor, process_monitor, psi) ]
                                       │
                                       ▼
                     [ engine.py : MonitorEngine ]
                      (Single coordination engine)
                                       │
                                       ▼
[ analyzer/ Layer: Baseline (MAD) + Attribution (PID+time) + BottleneckDetector V2 ]
                                       │
       ┌───────────────────────────────┴───────────────────────────────┐
       ▼                                                               ▼
[ Persistence : data/ ]                                     [ Presentation & Reports ]
 system_logs.csv                                             Streamlit Dashboard (9 Tabs)
 alerts.csv & latest.json                                    Executive Markdown Reports
```

### Speaker Notes (1 Minute)
> "Here is our system architecture. Collectors read directly from `/proc` and `/sys`. Notice an important design principle: the `analyzer/` package is completely pure and deterministic. It performs no I/O and has no kernel dependencies, making it 100% testable with synthetic data. Furthermore, the exact same MonitorEngine coordinates both normal background monitoring and our controlled experiment harness—there are no fake or specialized paths for tests."

---

## Slide 5: Operating System Concepts Mapped to Modules

### Visual Layout
| OS Concept | Theoretical Mechanism | Module Implementation |
|---|---|---|
| **Process Identity** | PID reuse in task table | `ProcessTracker` uses `(pid, start_time)` tuple |
| **Scheduler Latency** | Threads waiting in run queues | `CpuMonitor` computes wait deltas from `/proc/schedstat` |
| **Context Switching** | Register saving & pipeline flushes | `CpuMonitor` tracks `ctx_switches_s` per core |
| **Virtual Memory Cache** | Page cache reclamation vs exhaustion | `MemoryMonitor` uses `MemAvailable`, not `MemFree` |
| **Thrashing** | Page-in/page-out disk faults | `MemoryMonitor` calculates swap rates + major page faults |
| **Block Queue Depth** | Storage driver request queues | `DiskMonitor` calculates `await` latency & queue depth |
| **Kernel Task Stalls** | Work stalled on hardware | `PsiReader` calculates interval-exact stall % from `total` |

### Speaker Notes (1.5 Minutes)
> "This slide maps core Operating Systems principles directly to our codebase. For process management, we track process start times to ensure that when a PID is recycled, it does not inherit history. For scheduling, we read `/proc/schedstat` to measure runnable wait time directly. For memory, we respect page cache dynamics by using `MemAvailable`. For storage, we compute device latency and queue depth. And for stalls, we read Linux Kernel Pressure Stall Information."

---

## Slide 6: Mathematical Formulations & Detection Rules

### Visual Layout
- **Interval-Exact PSI Calculation:**
  $$\text{PSI Stall (\%)} = \min\left(100.0, \frac{\text{total}_{t_2} - \text{total}_{t_1}}{\Delta t \times 10^6} \times 100\right)$$
- **Median Absolute Deviation (MAD) Baseline:**
  $$\tilde{x} = \text{Median}(X), \quad \text{MAD} = \text{Median}(|X - \tilde{x}|), \quad Z = \frac{x - \tilde{x}}{\max(1.4826 \times \text{MAD}, \text{min\_scale})}$$
- **State Transition Matrix:**
  - $\text{Stall } (S) \land (\text{Saturation } (A) \lor \text{Utilization } (U)) \implies \mathbf{CONFIRMED}$
  - $\text{Stall } (S) \text{ only} \implies \mathbf{POTENTIAL}$
  - $\text{Utilization } (U) \text{ only} \implies \mathbf{ELEVATED}$
  - Contention cleared $\implies \mathbf{RECOVERED}$

### Speaker Notes (1.5 Minutes)
> "Here are the core mathematical formulas. Instead of relying on kernel averages like `avg10`—which lag by several seconds—we calculate the exact interval stall percentage from cumulative microsecond deltas. For our dynamic baseline, we use Median and MAD rather than mean and standard deviation, because MAD is immune to extreme outlier contamination. And our state engine requires both stall evidence and corroboration before confirming a bottleneck."

---

## Slide 7: Persistence, Severity & Process Attribution

### Visual Layout
- **Persistence Matrix:**
  - Window $W = 5$ samples, required $k = 3$ samples.
  - Spikes lasting 1 or 2 samples are suppressed, preventing false alarms.
- **Orthogonal Ratings:**
  - **Severity:** Overload magnitude (`INFO`, `WARNING`, `CRITICAL` — critical requires holding across the entire window).
  - **Confidence:** Consensus across independent kernel streams (`LOW`, `MEDIUM`, `HIGH` — high requires PSI + $\ge 3$ agreeing sensors).
- **Attribution Logic:**
  - Evaluates sustained load across the persistence window.
  - Verdicts: `primary` ($\ge 50\%$), `partial` ($15-49\%$), `multiple` ($\ge 2$), or `none` (diffuse/rotating load).

### Speaker Notes (1 Minute)
> "To prevent alarm fatigue, an indicator must persist in at least 3 of the last 5 samples. Notice how severity and confidence are orthogonal: a critical alert can have low confidence if only one sensor saw it, while a moderate alert can have high confidence if CPU, PSI, and run queues all agree. For attribution, we never blame the top process from a single sample; a process must persistently account for load across the window to be named as a primary contributor."

---

## Slide 8: Live Demonstration & Controlled Validation Harness

### Visual Layout
- **Controlled Experiment Harness:**
  - Automated 3-phase lifecycle: `Baseline` (idle) $\rightarrow$ `Stress` (bounded workload) $\rightarrow$ `Recovery` (clearance).
  - Works with the built-in Python generator or `stress-ng`.
- **The 3-Minute Live Demo Walkthrough:**
  1. **Healthy State:** `python main.py` + `streamlit run dashboard/app.py` $\implies$ System shows `NORMAL` (Green).
  2. **Negative Control:** `python experiment.py run cpu-benign` $\implies$ 100% CPU utilization, but dashboard displays `ELEVATED` (Blue). Zero bottlenecks!
  3. **Contention Injection:** `python experiment.py run cpu` $\implies$ Run queue and PSI spike; dashboard transitions to `CONFIRMED` (Red). Top contributor named!
  4. **Automatic Recovery:** Workload terminates $\implies$ Transition to `RECOVERED`, then back to `NORMAL`.

### Speaker Notes (1.5 Minutes)
> "We can demonstrate the exact detection mechanics in 3 minutes. First, the dashboard displays healthy baseline operations. Next, we run our negative control: `cpu-benign`. All cores reach 100% CPU, but the dashboard stays in ELEVATED. No contention alert is fired. Then, we execute `cpu` with oversubscribed workers. Within 3 seconds, PSI and run-queue wait spike, the alert turns to CONFIRMED, the worker process is attributed, and clear recommendations are displayed. Once the workload terminates, the detector logs a RECOVERED event and cleanly returns to NORMAL."

---

## Slide 9: Experimental Results & Self-Validation Metrics

### Visual Layout
| Experiment | Target | Detection Verdict | Mean Latency | Attribution Reliability | Clearance Time | Baseline False Positives |
|---|---|---|---|---|---|---|
| **`control`** | Idle System | **PASS** | N/A | N/A | Immediate | **0 / 50 (0.0%)** |
| **`cpu-benign`** | CPU | **PASS** | N/A (`ELEVATED`) | N/A | Immediate | **0 / 30 (0.0%)** |
| **`cpu`** | CPU | **PASS** | **3.02 s** | 28 / 28 (100%) | 3.06 s | 0.0% |
| **`disk`** | NVMe / Disk | **PASS** | **3.01 s** | 27 / 27 (100%) | 4.36 s | 0.0% |
| **`memory`** | RAM Reclaim | **PASS** | **9.00 s** | 3 / 3 (100%) | 1.31 s | 0.0% |

- **Unit Test Suite:** 175 Tests Passed (100% pass rate in 57.44s).
- **False-Positive Elimination:** Pooled false-positive rate across idle baselines and negative controls: **0.0%**.

### Speaker Notes (1 Minute)
> "Here are our empirical results. In all five categories, our detector passed validation. Detection latency for CPU and disk bottlenecks averaged 3.01 seconds, which perfectly matches our theoretical persistence filter of 3 samples at a 1-second interval. Crucially, across all baseline phases, idle control runs, and the 100% CPU benign test, our pooled false-positive rate was exactly 0.0%. Our unit test suite of 175 tests passes with 100% success."

---

## Slide 10: Limitations, Future Work & Conclusion

### Visual Layout
- **Identified Limitations:**
  - Non-root execution restricts foreign process I/O tracking (`/proc/<pid>/io`).
  - Asynchronous page-cache writeback creates a temporal delay between dirtying pages and disk commit.
  - Scope limited to host CPU, memory, and storage (no network or GPU monitoring).
- **Future Directions:**
  - eBPF kernel tracepoints (`sched_stat_wait`) for microsecond queuing latency.
  - Cgroup v2 hierarchical tree traversal for container / Kubernetes pod isolation.
- **Summary:**
  - Bottleneck Detective V2 delivers evidence-based, explainable, self-validating performance monitoring that eliminates false alarms and accurately pinpoints system contention.

### Speaker Notes (1 Minute)
> "To conclude, Bottleneck Detective V2 successfully bridges the gap between raw kernel metrics and actionable operational diagnosis. We acknowledge existing boundaries: unprivileged users cannot read foreign process I/O counters, and asynchronous writeback decouples file writes from block commits. In future work, we plan to integrate eBPF tracepoints and hierarchical cgroup v2 container inspection. Thank you, and I look forward to your questions."
