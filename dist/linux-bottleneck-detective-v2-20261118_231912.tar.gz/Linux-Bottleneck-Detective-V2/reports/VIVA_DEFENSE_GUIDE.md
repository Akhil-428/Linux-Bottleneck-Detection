# Linux Bottleneck Detective V2: Comprehensive Viva Defense Guide

**Operating Systems Project Defense & Viva Voce Reference**  
**Repository:** `Linux-Bottleneck-Detection`  
**Target Audience:** OS Viva Examiners, Faculty Evaluators, System Engineering Defense

---

## 1. Process Management & Lifecycle

### Q1: How does Linux represent processes in the kernel, and how does Bottleneck Detective read them?
**Answer:** The Linux kernel represents each process using `struct task_struct` maintained in the kernel task list. User-space utilities access this state via the pseudo-filesystem `/proc/<pid>/`. Bottleneck Detective reads `/proc/<pid>/stat` (for CPU jiffies, process state, start time, parent PID) and `/proc/<pid>/status` / `/proc/<pid>/statm` (for resident set size `VmRSS` and virtual memory size `VmSize`). Per-process I/O counters are obtained from `/proc/<pid>/io` (bytes read and written via syscalls).

### Q2: What are the primary Linux process states, and why does uninterruptible sleep (D state) matter for load average?
**Answer:** The primary states are:
- **`R` (TASK_RUNNING):** Currently executing on a CPU or waiting in a scheduler run queue.
- **`S` (TASK_INTERRUPTIBLE):** Sleeping, waiting for an event or signal (e.g., waiting for user input or timer).
- **`D` (TASK_UNINTERRUPTIBLE):** Sleeping, but cannot be interrupted by signals; almost always waiting for disk I/O, device driver response, or page-in from swap.
- **`T` (TASK_STOPPED / TASK_TRACED):** Suspended by SIGSTOP or debugger.
- **`Z` (TASK_DEAD / EXIT_ZOMBIE):** Terminated, waiting for parent to collect exit status via `waitpid()`.

**Critical OS Nuance:** Unlike traditional Unix, the Linux load average calculation includes both tasks in `R` state and tasks in `D` state. Therefore, a high load average does not necessarily mean high CPU demand—it often indicates tasks blocked waiting for slow storage or network filesystems.

### Q3: Why is PID alone insufficient as a unique process identifier? How does the engine solve PID recycling?
**Answer:** PIDs are finite integers allocated from `/proc/sys/kernel/pid_max` (typically 32,768 or 4,194,304). On busy systems, short-lived processes (compilers, build scripts, containers) terminate and their PIDs are recycled by the kernel. If a monitoring tool indexes processes solely by PID, a newly created process inheriting an old PID will erroneously inherit the historical resource consumption of its predecessor.  
**V2 Solution:** The engine identifies every process by the composite tuple:
$$\text{Identity} = (\text{PID}, \text{start\_time})$$
where `start_time` is the process creation timestamp in clock jiffies since system boot (field 22 of `/proc/<pid>/stat`). When a PID is recycled, its `start_time` changes, causing the `ProcessTracker` to immediately purge historical attribution for that slot.

### Q4: How does the workload supervisor ensure child processes never become orphaned if the supervisor is killed?
**Answer:** The project implements three layers of defense:
1. **Internal Worker Deadline:** Every worker process computes an absolute wall-clock deadline (`time.monotonic() + seconds + 3.0`) and self-terminates when reached.
2. **`PR_SET_PDEATHSIG`:** Upon startup, each worker invokes `prctl(PR_SET_PDEATHSIG, SIGTERM)`. If the parent supervisor process dies (even via `SIGKILL`), the Linux kernel automatically delivers `SIGTERM` to all child workers.
3. **Dedicated Process Groups:** Workloads are spawned with `start_new_session=True` or `setpgid()`. The supervisor terminates entire process groups (`os.killpg()`), verifying group ownership before signaling so foreign processes are never touched.

---

## 2. CPU Scheduling & Queuing

### Q5: How is CPU utilization calculated from `/proc/stat`? Why is a single read meaningless?
**Answer:** Cumulative ticks (jiffies since boot) for each CPU state (`user`, `nice`, `system`, `idle`, `iowait`, `irq`, `softirq`, `steal`) are exported in `/proc/stat`. Because these counters are monotonic cumulative totals, a single read provides only the total uptime since boot. To compute instantaneous utilization, two reads separated by time $\Delta t$ are required:
$$\Delta \text{Total} = \sum_{\text{all fields}} (c_{t_2} - c_{t_1}), \quad \Delta \text{Idle} = (\text{idle}_{t_2} - \text{idle}_{t_1}) + (\text{iowait}_{t_2} - \text{iowait}_{t_1})$$
$$\text{CPU Utilization (\%)} = \left( \frac{\Delta \text{Total} - \Delta \text{Idle}}{\Delta \text{Total}} \right) \times 100$$

### Q6: How does the engine measure CPU run-queue wait time without polling?
**Answer:** When the kernel is compiled with `CONFIG_SCHEDSTATS`, `/proc/schedstat` exports per-CPU scheduler statistics. Field 8 of CPU records tracks the cumulative nanoseconds that runnable tasks spent waiting on the run queue before being scheduled onto a core. The engine calculates:
$$\text{runq\_wait\_per\_core} = \frac{\sum_{\text{cpu}} \Delta \text{wait\_nanoseconds}}{\Delta t \times 10^9 \times N_{\text{cores}}}$$
If `schedstat` is unavailable, the engine gracefully falls back to sampling `procs_running` from `/proc/stat`, computing runnable surplus as $(procs\_running - 1) / cores$.

### Q7: If CPU utilization is 100%, is the system definitely bottlenecked?
**Answer:** **No.** 100% CPU utilization indicates high resource utilization, not necessarily contention or degradation. If an application utilizes 100% of all cores with zero runnable tasks waiting in scheduler queues and zero Pressure Stall Information stalls, the system is executing at optimal computational throughput. A bottleneck occurs only when tasks that are ready to run are delayed because capacity is saturated. Bottleneck Detective V2 categorizes 100% CPU with empty queues as **`ELEVATED`** (`INFO` level), reserving **`CONFIRMED`** for situations with elevated run-queue latency and kernel PSI stalls.

### Q8: What does context switch rate indicate, and why is it treated as supporting evidence only?
**Answer:** A context switch involves saving the current task's architectural registers, program counter, and stack pointer, updating kernel scheduling structures, and loading the new task's state and memory translation tables (CR3 register / MMU page tables). High context switch rates indicate scheduler churn, lock contention, or thread thrashing. However, high context switching can also occur in healthy asynchronous I/O architectures (e.g., event loops). Therefore, Bottleneck Detective V2 treats context switch rates per core strictly as **supporting evidence** to corroborate CPU contention, never as an isolated alert trigger.

---

## 3. Virtual Memory & Paging

### Q9: Why does the engine use `MemAvailable` rather than `MemFree` to assess memory pressure?
**Answer:** In the Linux virtual memory architecture, `MemFree` represents completely unallocated physical RAM. However, the kernel deliberately populates unused memory with file-backed page cache (`Cached`), buffer cache (`Buffers`), and reclaimable slab objects (`SReclaimable`) to accelerate I/O. If application demand increases, the kernel's memory management subsystem reclaims this cached memory without swapping. `MemAvailable` (introduced in Linux 3.14) provides an accurate kernel estimate of physical memory that can be allocated immediately without forcing the system into swap thrashing. Evaluating memory based on `MemFree` generates persistent false positives.

### Q10: What is the critical distinction between swap *usage* and swap *activity*?
**Answer:** 
- **Swap Usage:** The static volume of data residing in the swap partition or swap file. Inactive or abandoned memory pages (e.g., daemons initialized at boot that are never referenced) can reside in swap indefinitely with zero performance penalty.
- **Swap Activity:** The real-time rate of swapping pages out (`pswpout` in `/proc/vmstat`) and, crucially, swapping pages in (`pswpin`). Active swap-in indicates that currently referenced working sets exceed physical RAM capacity, causing page faults that require disk I/O to resolve. This condition (thrashing) halts useful thread execution. The detector triggers memory saturation only when swap activity occurs while physical memory is constrained.

### Q11: What is the Linux Out-Of-Memory (OOM) Killer, and how does the experiment harness interact with it?
**Answer:** When physical memory and swap are completely exhausted and page cache reclaim fails, the kernel invokes the OOM Killer to prevent a full system freeze. The kernel computes an `oom_score` for each process based on physical memory consumption and adjusts it using `/proc/<pid>/oom_score_adj` (ranging from -1000 to +1000).  
**Harness Safeguard:** In the experiment harness, memory workers explicitly write `1000` to `/proc/self/oom_score_adj`. This designates the stress worker as the kernel's preferred sacrifice if memory reaches critical limits, protecting desktop processes and system daemons.

---

## 4. Block Storage & I/O

### Q12: Why is device `%util` from `/proc/diskstats` unreliable on modern SSD and NVMe drives?
**Answer:** Device `%util` measures the percentage of time during which at least one I/O request was in flight. On legacy mechanical hard drives (HDDs) that process one request at a time via a physical head, `%util = 100%` correlates directly with hardware saturation. However, modern solid-state drives (NVMe) feature deep hardware command queues (e.g., 64,000 queues with 64,000 commands each) and execute requests concurrently across parallel NAND channels. An NVMe drive handling 1 request continuously reports `%util = 100%`, yet has vast remaining throughput and IOPS capacity. The engine therefore correlates `%util` with average request latency (`await`), average queue depth (`aqu-sz`), and I/O Pressure Stall Information (`psi/io`).

### Q13: How does the engine compute per-device `await` latency?
**Answer:** In `/proc/diskstats`, field 4 (`read_ticks`) and field 8 (`write_ticks`) track cumulative milliseconds spent processing reads and writes, while field 1 (`reads_completed`) and field 5 (`writes_completed`) track total I/O count. The engine computes:
$$\text{await} = \frac{\Delta \text{read\_ticks} + \Delta \text{write\_ticks}}{\max(1, \Delta \text{reads\_completed} + \Delta \text{writes\_completed})} \quad [\text{ms}]$$
This metric represents the average time an I/O request spent from submission to completion (queue latency + device service time).

### Q14: What is the difference between device-level saturation and application-level I/O waiting?
**Answer:** 
- **Device-Level Saturation:** A physical block device exhibits elevated `%util`, high `await` latency, and deep queue depth, while tasks stall in I/O wait. Hardware capacity is saturated.
- **Application-Level I/O Waiting:** Tasks experience significant I/O stalls (measured via `psi/io` or high `iowait`), but no individual block device exhibits high utilization or queue depth. This occurs during frequent synchronous `fsync()` flushes (where threads block waiting for cache flushes despite low data volume), cgroup I/O throttling, or delays over network/virtual filesystems (NFS, overlayfs). The engine distinguishes these two regimes cleanly in its diagnoses.

---

## 5. Linux Kernel Pressure Stall Information (PSI)

### Q15: What is Pressure Stall Information (PSI), and what is the difference between `some` and `full` stalls?
**Answer:** Kernel Pressure Stall Information (introduced in Linux 4.20) directly quantifies the productivity lost to resource starvation across CPU, Memory, and I/O:
- **`some`:** The percentage of wall-clock time during which at least one non-idle task was stalled waiting for that resource.
- **`full`:** The percentage of wall-clock time during which *all* non-idle tasks were simultaneously stalled on the resource. When `full` stall occurs, no useful compute work is being performed by any task.
- *Note on CPU:* System-wide `cpu.full` is not defined because at least one task is always executing if CPU is busy; CPU only exports `some`. Memory and I/O export both `some` and `full`.

### Q16: Why does the detector calculate interval-exact PSI from `total` rather than using `avg10`?
**Answer:** The kernel exports smoothed moving averages: `avg10`, `avg60`, and `avg300`. Because `avg10` is an exponentially damped 10-second window, it exhibits significant lag: it requires several seconds to rise after stress begins and continues to show high stall percentages long after the workload has ceased. The engine calculates:
$$\text{Interval Stall (\%)} = \frac{\Delta \text{total\_microseconds}}{\Delta t \times 10^6} \times 100$$
This interval-exact delta responds immediately at the onset of contention and recovers to zero the instant tasks stop waiting.

---

## 6. Architecture & Detection Engine Design

### Q17: Why use a 3-of-5 persistence filter instead of alerting on individual spikes?
**Answer:** Real-world operating systems exhibit frequent transient resource spikes: a browser rendering a webpage, a compiler opening header files, or a periodic cron job. These spikes naturally subside in 1–2 seconds without degrading overall service. Requiring an indicator to persist in $\ge 3$ of the last 5 samples filters out high-frequency noise while guaranteeing a deterministic detection response time of approximately 3 seconds at a 1-second sampling interval.

### Q18: Why are Severity and Confidence modeled as separate, orthogonal dimensions?
**Answer:** 
- **Severity** reflects the magnitude of the overload: how far past safe operating thresholds the system has been pushed (`INFO`, `WARNING`, `CRITICAL`).
- **Confidence** reflects the consistency and corroboration of independent kernel data streams (`LOW`, `MEDIUM`, `HIGH`).
A diagnosis can be `CRITICAL` in severity (e.g., 99% CPU utilization) but have `LOW` confidence if only one sensor registered it and PSI stalls are absent. Conversely, a moderate overload with agreeing CPU, run queue, and PSI telemetry yields `HIGH` confidence. Conflating them hides critical diagnostic context from operators.

### Q19: Why use Median and MAD for baselines instead of Mean and Standard Deviation?
**Answer:** The arithmetic mean ($\mu$) and standard deviation ($\sigma$) are parametric statistics that are easily skewed by extreme outliers. In a performance monitor, the very bottleneck spikes being detected would artificially inflate the mean and expand the standard deviation, blinding the detector to subsequent anomalies. The Median ($\tilde{x}$) and Median Absolute Deviation ($\text{MAD}$) are non-parametric estimators with a breakdown point of 50%, meaning that up to half the sample window can consist of extreme outliers without corrupting the baseline.

### Q20: What critical bug was uncovered by the negative control (`cpu-benign`)?
**Answer:** During initial development of the baseline engine, an idle system established a run-queue median of 0. When `cpu-benign` executed (pegging cores at 100% with exactly 1 task per core), `procs_running` shifted from 0 to 1 per core. Statistically, this produced a modified $Z$-score greater than $+30$, causing the baseline engine to falsely flag CPU contention. The negative control exposed that statistical deviation alone is insufficient: every metric family requires an **absolute floor** ($\text{min\_abs\_floor}$) in addition to $Z$-score and minimum delta, ensuring that normal, fully occupied core execution is never mistaken for queue starvation.

---

## 7. Viva Defense Strategy & Live Demo Walkthrough

### The 3-Minute Demo Flow (Reference: `docs/VIVA.md` Section G)
1. **Initial Baseline:** Start `main.py` and `streamlit run dashboard/app.py`. Show the green `NORMAL` status across CPU, Memory, and Disk.
2. **Negative Control:** Execute `.venv/bin/python experiment.py run cpu-benign`. Show CPU utilization rising to ~100%, while the dashboard displays `ELEVATED` (Blue). Emphasize: *100% CPU is not a bottleneck when run queues and PSI stalls remain zero.*
3. **Contention Injection:** Execute `.venv/bin/python experiment.py run cpu`. Show run queue wait times and PSI rising; dashboard immediately transitions to `CONFIRMED` (Red). Highlight the attributed worker process and evidence table.
4. **Recovery Event:** Workload terminates; demonstrate immediate transition to `RECOVERED` with duration tracking, followed by clean return to `NORMAL`.
5. **Report Artifact:** Open the generated `report.md` and `timeline.png` to show automated empirical validation.
